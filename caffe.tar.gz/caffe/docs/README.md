# Caffe Documentation

To generate the documentation, run `$CAFFE_ROOT/scripts/build_docs.sh`.

To push your changes to the documentation to the gh-pages branch of your or the BVLC repo, run `$CAFFE_ROOT/scripts/deploy_docs.sh <repo_name>`.
